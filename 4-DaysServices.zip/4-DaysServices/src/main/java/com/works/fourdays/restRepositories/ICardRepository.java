package com.works.fourdays.restRepositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.works.fourdays.model.Card;

@Repository
public interface ICardRepository extends JpaRepository<Card, Long> {
	
	@Query(" select c from Card c where c.ctelephone = ?1 ")
	public Card findTelephone(String telephone);

}
