package com.works.bootmvc.model;

public class Card {

	private String cname;
	private String csurname;
	private String ctelephone;
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCsurname() {
		return csurname;
	}
	public void setCsurname(String csurname) {
		this.csurname = csurname;
	}
	public String getCtelephone() {
		return ctelephone;
	}
	public void setCtelephone(String ctelephone) {
		this.ctelephone = ctelephone;
	}
	
	
	
}
