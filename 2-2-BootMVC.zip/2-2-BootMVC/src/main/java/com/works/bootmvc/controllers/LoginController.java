package com.works.bootmvc.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import utils.Util;

@Controller
public class LoginController {
	
	static String id = "";
	
	@GetMapping("/login")
	public String login( HttpServletRequest req ) {
		
		id = req.getSession().getId();
		System.out.println("Sessin id " + id);
		
		return "login";
	}
	
	
	// user login post
	@PostMapping("/userLogin")
	public String userLogin( 
			@RequestParam String mail,
			@RequestParam String pass,
			@RequestParam(defaultValue = "") String remember_me,
			HttpServletRequest req,
			HttpServletResponse res
			) 
	{
		if ( mail.equals("ali@ali.com") && pass.equals("12345") ) {
			
			// Cookie insert
			if (!remember_me.equals("")) {
				Cookie cookie = new Cookie("user_cookie", Util.sifrele(mail, 3));
				cookie.setMaxAge(60*60*24);
				res.addCookie(cookie);
			}
			
			// session create
			req.getSession().setAttribute("user", mail);
			return "redirect:/";
		}
		
		return "redirect:/login";
	}
	

}
