package com.works.bootmvc.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.works.bootmvc.props.User;

@Controller
public class HomeController {

	@RequestMapping(name = "/", method = RequestMethod.GET)
	public String home() {
		// push data home.jsp
		//model.addAttribute("data", "Şampiyon Fenerbahçe");
		return "home";
	}
	
	//@RequestMapping(name = "/userInsert", method = RequestMethod.POST)
	// @RequestParam String mail
	@PostMapping("/userInsert")
	public String userInsert( User us ) {
		System.out.println("Mail : " + us.getName());
		System.out.println("Surname : " + us.getSurname());
		System.out.println("Uid : " + us.getUid());
		return "redirect:/";
	}
	
	
}
