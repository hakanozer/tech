package com.works.bootmvc.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.works.bootmvc.model.Card;
import com.works.bootmvc.model.Test;
import com.works.bootmvc.props.User;

import utils.Util;

@Controller
public class HomeController {
	
	List<Card> ls = new ArrayList<Card>();
	
	public HomeController() {
		System.out.println(" HomeController Call ");
	}
	
	//SessionFactory sf = HibernateUtil.getSessionFactory();

	@RequestMapping(name = "/", method = RequestMethod.GET)
	public String home(  Model model, HttpServletRequest req ) {
		// push data home.jsp
		//model.addAttribute("data", "Şampiyon Fenerbahçe");
		
		// Cookie control
		if (req.getCookies() != null) {
			Cookie[] arr = req.getCookies();
			for (Cookie cookie : arr) {
				if( cookie.getName().equals("user_cookie") ) {
					String val = cookie.getValue();
					req.getSession().setAttribute("user", Util.sifreCoz(val, 3));
					LoginController.id = req.getSession().getId();
				}
			}
		}
		
		
		String id = req.getSession().getId();
		if (!id.equals(LoginController.id)) {
			return "redirect:/login";
		}
		
		// session contol
		boolean statu = req.getSession().getAttribute("user") == null;
		if (statu) {
			return "redirect:/login";
		}
		
		
		model.addAttribute("ls", ls);
		return "home";
	}
	
	//@RequestMapping(name = "/userInsert", method = RequestMethod.POST)
	// @RequestParam String mail
	@PostMapping("/userInsert")
	public String userInsert( Card cr ) {
		
		ls.add(cr);
		
		/*
		Session sesi = sf.openSession();
		Transaction tr = sesi.beginTransaction();
		
		Test ts = new Test();
		ts.setTdata("merhaba");
		
		// vt insert
		sesi.save(ts);
		
		tr.commit();
		sesi.close();
		*/
		
		return "redirect:/";
	}
	
	// @RequestParam String data
	@GetMapping("/delete/{data}")
	public String deleteItem( @PathVariable String data ) {
		System.out.println(data);
		ls.remove(0);
		return "redirect:/";
	}
	
	
	
}
