package appPack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainApp {
	
	
	static List<User> ls = new ArrayList<User>();

	public static void main(String[] args) {
		
		dataResult();
		
		// Stream Api
		long start = System.currentTimeMillis();
		ls.stream()
		.filter(item -> item.getId() > 0)
		.forEach(item -> {
			//System.out.println(item.getName());
		});
		long end = System.currentTimeMillis();
		long between = end - start;
		System.out.println("stream between : " + between);
		
		// paralel stream
		start = System.currentTimeMillis();
		ls.parallelStream()
		.filter(item -> item.getId() > 0)
		.forEach(item -> {
			//System.out.println(item.getName());
		});
		end = System.currentTimeMillis();
		between = end - start;
		System.out.println("parallelStream between : " + between);
		
		
		// String +
		String data = "days";
		String con = "1. " + data;
		
		StringBuilder sb = new StringBuilder();
		sb.append("1. ");
		sb.append("days");
		System.out.println(sb.toString());
		
		

	}
	
	
	public static void dataResult() {
		
		for (int i = 0; i < 100000; i++) {
			User us = new User();
			us.setId(i);
			us.setName("ali" + i);
			us.setRd(new Random());
			ls.add(us);
		}
		
	}

}
