package appPack;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MainApp {

	public static void main(String[] args) {
		
		//String surname = "' or '1' = 1' delete from user ";
		DB db = new DB();
		
		
		String query = "insert into user values ( null, ?, ?, now() )";
		try {
			PreparedStatement pre = db.connect(query);
			pre.setString(1, "Ayşe");
			pre.setString(2, "Bilsin");
			int statu = pre.executeUpdate(); // insert, update, delete
			ResultSet ids = pre.getGeneratedKeys();
			if(ids.next()) {
				int id = ids.getInt(1);
				System.out.println("insert id : " + id);
			}
			if ( statu > 0 ) {
				System.out.println("insert seccess");
			}else {
				System.out.println("insert fail");
				// db.conn.rollback();
				// db.conn.commit();
			}
			
		} catch (Exception e) {
			System.err.println("insert error : " + e);
		}
		dataResult();
	}
	
	
	
	public static void dataResult() {
		
		DB db = new DB();
		String query = "select * from user where name = ? ";
		
		try {
			PreparedStatement pre = db.connect(query);
			pre.setString(1, "Ayşe");
			ResultSet rs = pre.executeQuery();
			
			while(rs.next()) {
				int id = rs.getInt("uid");
				String name = rs.getString("name");
				System.out.println("uid : " + id);
				System.out.println("Name : " + name);
			}
			
			// single
			if (rs.next()) {
				int id = rs.getInt("uid");
				String name = rs.getString("name");
				System.out.println("single uid  : " + id);
				System.out.println("single Name : " + name);
			}
			
		} catch (Exception e) {
			System.err.println("select error : " + e);
		}
		
	}
	
	
	
	
	
	
	
	
	
	

}
