package appPack;

public class MainApp {

	public static void main(String[] args) {
		
		DB db = new DB();
		db.connect("");

	}

}
