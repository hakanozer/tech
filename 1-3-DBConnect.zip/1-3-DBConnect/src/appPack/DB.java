package appPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class DB {
	
	private final String driver = "com.mysql.jdbc.Driver";
	private final String url = "jdbc:mysql://localhost/tech?useUnicode=true&characterEncoding=utf-8";
	private final String dbUserName = "root";
	private final String dbUserPass = "";
	
	private Connection conn = null;
	private PreparedStatement pre = null;
	
	
	public PreparedStatement connect( String query ) {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbUserName, dbUserPass);
			// pre = conn.prepareStatement(query);
			System.out.println("Connection Success");
		} catch (Exception e) {
			System.err.println("DB Error : " + e);
		}
		return pre;
	}
	
	
}
