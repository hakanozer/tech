package appPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class DB {
	
	private final String driver = "com.mysql.jdbc.Driver";
	private final String url = "jdbc:mysql://localhost/tech?useUnicode=true&characterEncoding=utf-8";
	private final String dbUserName = "root";
	private final String dbUserPass = "";
	
	public Connection conn = null;
	private PreparedStatement pre = null;
	
	
	public PreparedStatement connect( String query ) {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbUserName, dbUserPass);
			pre = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			System.out.println("Connection Success");
			// conn.setAutoCommit(false);
		} catch (Exception e) {
			System.err.println("DB Error : " + e);
		}
		return pre;
	}
	
	
}
