package apppack;

public class Settings {
	
	public Settings() {
		System.out.println("Default Settings");
	}
	
	public Settings( String data ) {
		System.out.println("Settings " + data);
		fncPicture();
	}
	
	public void test() {
		System.out.println("Hello Java");
	}
	
	public int a = 10;
	public String name = "Mehmet";
	final int age = 40;
	
	final void fncUser() {
		System.out.println("final fncUser");
	}
	
	static void fncPicture() {
		System.out.println("static fncPicture");
	}

}
