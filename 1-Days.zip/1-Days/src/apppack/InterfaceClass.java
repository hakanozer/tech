package apppack;

import iUsers.IUserSettings;

public class InterfaceClass implements IUserSettings {

	@Override
	public void userCall() {
		
		innerCall in = new innerCall();
		in.tst();
		// end = 50; fail
		int i = minus(40, 10);
		System.out.println("Hello interface " + i);
		System.out.println("end : " + end);
	}

	@Override
	public int sum(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}
