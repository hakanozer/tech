package apppack;

import java.util.ArrayList;
import java.util.List;

import abs.AbsUser;
import appPackTwo.User;
import appPackTwo.Util;
import iUsers.IUserDepo;
import iUsers.IUserSettings;

public class MainApp extends AbsUser {

	public static void main(String[] args) {
		
		Settings st = new Settings();
		Util ut = new Util();
		User us = new User();
		
		call(st);
		call(ut);
		call(us);
		
		List<String> ls = new ArrayList<>();
		Settings utx = new Util();
		
		ArrayList<String> als = new ArrayList<>();
		
		IUserSettings usts = new InterfaceClass();
		//usts.userCall();
		callIner(usts);
		
		IUserDepo userDepo = new IUserDepo() {
			
			@Override
			public void userCall() {
				System.out.println("userCall  " + a);
				xx();
			}
			
			int a = 10;
			
			public void xx() {
				System.out.println("xx call");
			}
			
		};
		userDepo.userCall();
		userDepo.testX();

		
		
	}
	
	
	public static void call(Settings st) {
		
		if (st instanceof Util) {
			Util ut = (Util) st;
			ut.callX();
		}
		
		st.test();
		
	}
	
	
	public static void callIner( IUserSettings ust ) {
		ust.userCall();
	}


	@Override
	public int sum(int a, int b) {
		return a + b;
	}
	

}
