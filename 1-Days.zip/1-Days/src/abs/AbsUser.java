package abs;

import java.util.Random;

public abstract class AbsUser extends Random {

	abstract public int sum( int a, int b );
	
	public void absTest() {
		System.out.println("absTest call");
	}
	
}
