package iUsers;

import apppack.Settings;

public interface IUserSettings extends IUserDepo {
	
	int end = 100;
	
	public int sum(int a, int b);
	
	default public int minus(int a, int b) {
		return a - b;
	}
	
	class innerCall extends Settings {
		
		
		
		public void tst() {
			System.out.println("innerCall tst");
		}
	}

}
