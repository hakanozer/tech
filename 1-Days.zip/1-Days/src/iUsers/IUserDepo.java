package iUsers;

public interface IUserDepo {

	public void userCall();
	
	default public void testX() {
		System.out.println("test yapılsın");
	}
	
}
