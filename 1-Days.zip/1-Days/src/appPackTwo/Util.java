package appPackTwo;

import apppack.Settings;

public class Util extends Settings {
	
	public Util() {
		super("Kurucu Util");
	}

	@Override
	public void test() {
		System.out.println("Hello Days");
	}
	
	public void callX() {
		System.out.println("Callx Call");
		a = 100;
		//age = 41;
		boolean statu = false;
		if(statu) {
			test();
		}else {
			super.test();
		}
	}
	

		
}
