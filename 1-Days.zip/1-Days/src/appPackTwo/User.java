package appPackTwo;

import apppack.Settings;

public class User extends Settings {

	@Override
	public void test() {
		System.out.println("Hello User");
	}
	
}
