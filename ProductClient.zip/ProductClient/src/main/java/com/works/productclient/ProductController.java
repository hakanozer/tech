package com.works.productclient;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	@GetMapping("/allProduc")
	public Map<String, Object> allProduc() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		
		Product pr1 = new Product();
		pr1.setTitle("Buzdolabı");
		pr1.setPrice(2000);
		
		Product pr2 = new Product();
		pr2.setTitle("Televizyon");
		pr2.setPrice(1000);
		
		List<Product> ls = new ArrayList<Product>();
		ls.add(pr1);
		ls.add(pr2);
		
		hm.put("statu", true);
		hm.put("allProduc", ls);
		
		return hm;
	}

}
