package com.works.productclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
