package com.works.loglombook;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@GetMapping("/user")
	public Map<String, Object> user() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		
		List<Integer> data = Arrays.asList(1,2,3,4,5);
		logger.debug("debug one errors fail" + data);
		logger.error("error one errors fail" , data.toString());
		logger.trace("trace one errors fail" + data);
	
		
		User us =  new User();
		us.setName("Ali");
		us.setAge(40);
		hm.put("user", us);
		
		
		String pattern = "mm-dd-yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		
		try {
			Date date;
			date = simpleDateFormat.parse("12-01-2018");
			System.out.println(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return hm;
	}
	
	
}
