package com.works.clientSoap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.works.clientSoap.bindings.GetBookRequest;
import com.works.clientSoap.bindings.GetBookResponse;
import com.works.clientSoap.client.SoapClient;

@RestController
public class BookController {
	
	
	@Autowired SoapClient soapClient;
	
	@PostMapping("/getBooks")
	public GetBookResponse item( @RequestBody GetBookRequest bookRequest ) {
		return soapClient.getItem(bookRequest);
	}

}
