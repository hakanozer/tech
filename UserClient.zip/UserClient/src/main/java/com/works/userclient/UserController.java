package com.works.userclient;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



@RestController
public class UserController {
	
	
	@Autowired DiscoveryClient discoveryClient;
	
	@GetMapping("/userData")
	public Map<String, Object> userData() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		
		List<ServiceInstance> instances = discoveryClient.getInstances("Product-Client");
		if(instances != null && !instances.isEmpty() ) {
			ServiceInstance serviceInstance = instances.get(0);
			String url = serviceInstance.getUri().toString();
			System.out.println("url : " + url);
			hm.put("url", url);
			
			RestTemplate restTemplate = new RestTemplate();
			String data = restTemplate.getForObject(url+"/allProduc", String.class);
			System.out.println("Data : " + data);
			
		}
		
		return hm;
	}
	
	
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	
	
	
}
