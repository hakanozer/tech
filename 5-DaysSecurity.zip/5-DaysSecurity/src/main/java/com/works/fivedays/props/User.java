package com.works.fivedays.props;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.works.fivedays.usingValidation.UniValid;

public class User {
	
	@NotBlank(message = "Name boş olamaz")
	@NotEmpty(message = "Name datası giriniz")
	private String name;
	
	@Min(value = 10, message = "en az 10 değeri giriniz")
	@Max(value = 100, message = "en fazla 100 değeri giriniz")
	private int age;
	
	@Email(message = "Lütfen mail formatı giriniz!")
	private String mail;
	
	@UniValid(message = "Lütfen geçerli bir üni. girin.")
	private String uni;
	
	
	public String getUni() {
		return uni;
	}
	public void setUni(String uni) {
		this.uni = uni;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	

}
