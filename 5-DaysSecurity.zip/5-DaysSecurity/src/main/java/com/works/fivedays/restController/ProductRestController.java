package com.works.fivedays.restController;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.works.fivedays.utils.Util;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	
	
	@PostMapping("/allProduct")
	public Map<String, Object> allProduct( ) 
	{
		Util.adminStatu();
		// Control
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("statu", true);
		hm.put("product", "Buzdolabı A21");
		
		return hm;
	}
	
	
	@ResponseStatus( code = HttpStatus.BAD_REQUEST )
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, Object> errorFnc() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("statu", false);
		return hm;
	}
	
	
	

}
