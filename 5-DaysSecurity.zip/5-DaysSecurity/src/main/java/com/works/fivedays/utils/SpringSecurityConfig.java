package com.works.fivedays.utils;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired DataSource db;
	
	// db table control
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		auth.
		jdbcAuthentication()
		.dataSource(db)
		.authoritiesByUsernameQuery(" select amail, arole from admin where amail = ?")
		.usersByUsernameQuery(" select amail, apass, astatu from admin where amail = ? ");
		
	}
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		

		/*
		http
		.antMatcher("/**")
        .authorizeRequests()
        .antMatchers("/user/**").hasRole("user")
        .antMatchers("/product/**").hasRole("product")
        .and()
        .httpBasic();
        */
	    	

		
		http
		.httpBasic()
		.and()
		.authorizeRequests()
		.antMatchers("/user").hasRole("role_user")
		.antMatchers("/product").hasRole("role_product")
		.anyRequest()
		.authenticated();
		
		
		http.csrf().disable();
		
	}
	
	
	
	@Bean
	public static NoOpPasswordEncoder passwordEncoder() {
		return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
	}
	
	
}
