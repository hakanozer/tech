package com.works.fivedays.usingValidation;

import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UniValidClass implements ConstraintValidator<UniValid, String> {

	List<String> ls = Arrays.asList("istanbul", "ankara", "izmir", "bursa");
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		return ls.contains(value);
	}
	

	
}
