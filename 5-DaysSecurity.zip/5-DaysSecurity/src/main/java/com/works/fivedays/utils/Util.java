package com.works.fivedays.utils;

import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

public class Util {
	
	
	public static Object adminStatu() {
		
		Collection<? extends GrantedAuthority> aut = SecurityContextHolder
				.getContext()
				.getAuthentication()
				.getAuthorities();
		Authentication au = SecurityContextHolder.getContext().getAuthentication();
		System.out.println("Users : " + au.getName());
		System.out.println("Data : " + aut.toArray()[0]);
		return aut;
		
	}

}
