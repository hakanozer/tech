package com.works.fivedays.restController;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.el.MethodNotFoundException;
import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.works.fivedays.props.User;
import com.works.fivedays.utils.Util;

@RestController
@RequestMapping("/user")
public class UserRestController {
	
	
	@GetMapping("/insert")
	public Map<String, Object> insert( @RequestParam String name, @RequestParam String surname ) 
	{
		Util.adminStatu();
		// Control
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("name", name);
		hm.put("surname", surname);
		
		return hm;
	}
	
	
	
	@PostMapping("/jsonUser")
	public Map<String, Object> jsonUser( @RequestBody @Valid User us ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("statu", true);
		hm.put("user", us);
		return hm;
	}
	
	
	@ResponseStatus( code = HttpStatus.BAD_REQUEST )
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, Object> errorFnc(  MethodArgumentNotValidException ex ) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("statu", false);
		ex.getBindingResult().getAllErrors().forEach(err -> {
			String field = (( FieldError) err).getField();
			hm.put("error", err.getDefaultMessage());
			hm.put("field", field);
		});
		return hm;
	}
	
	

}
