package props;

public enum UEnum {

	name, surname, age;
	
}
